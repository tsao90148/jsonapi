# jsonapi

# Description
Initial release: Supports two API's:
-dumps
-loads
and two custom classes to be used encoding and decoding:
-BetterEncoder
-BetterDecoder

# Installation